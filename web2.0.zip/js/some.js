function getPositionMove(event) {
    mouseX = event.pageX;
    mouseY = event.pageY;
    mouseYHelp = event.clientY;
    mousePoint = document.getElementById('mousePoint');
    mousePoint.style.left = mouseX - 50 + 'px';
    mousePoint.style.top = mouseY - 50 + 'px';
}
function getPositionScroll(event) {
    scrolledY = window.scrollY;
    mousePoint = document.getElementById('mousePoint');
    currentTop = parseFloat(mousePoint.style.top);
    mousePoint.style.top = (scrolledY + mouseYHelp - 50) + 'px';
}